import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const workerId = '\0paperplane-inline-worker';
export default defineConfig({
  base: './',
  plugins: [
    {
      name: 'paperplane-inline-pdf-worker',
      enforce: 'pre',
      resolveId(id) {
        if (id === 'pdfjs-dist/build/pdf.worker.min.mjs?url') return workerId;
      },
      load(id) {
        if (id !== workerId) return;
        const code = readFileSync(require.resolve('pdfjs-dist/build/pdf.worker.min.mjs'), 'utf8');
        return `export default URL.createObjectURL(new Blob([${JSON.stringify(code)}], {type: 'text/javascript'}));`;
      },
      transformIndexHtml(html) {
        const icon = readFileSync(new URL('./public/favicon.svg', import.meta.url), 'base64');
        return html.replace(/href="(?:\.\/|\/)favicon\.svg"/, `href="data:image/svg+xml;base64,${icon}"`);
      },
    },
    react(),
    viteSingleFile(),
  ],
  build: { outDir: 'offline', copyPublicDir: false, target: 'es2022' },
});
