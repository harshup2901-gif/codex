import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { deflateSync } from 'node:zlib';
import { chromium } from 'playwright';
import { PDFDocument } from 'pdf-lib';
import JSZip from 'jszip';

const baseUrl = process.env.PAPERPLANE_TEST_URL || 'http://localhost:5173';
const outputDir = path.resolve('test-results');
const fixtureDir = path.join(outputDir, 'fixtures');
const downloadDir = path.join(outputDir, 'downloads');
await fs.mkdir(fixtureDir, { recursive: true });
await fs.mkdir(downloadDir, { recursive: true });

function crc32(data) {
  let crc = 0xffffffff;
  for (const byte of data) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const body = Buffer.concat([Buffer.from(type), data]);
  const size = Buffer.alloc(4);
  size.writeUInt32BE(data.length);
  const checksum = Buffer.alloc(4);
  checksum.writeUInt32BE(crc32(body));
  return Buffer.concat([size, body, checksum]);
}

function landscapePng() {
  const width = 850;
  const height = 600;
  const data = Buffer.alloc(height * (width * 3 + 1));
  let random = 12345;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width * 3; x += 1) {
      random = (Math.imul(random, 1664525) + 1013904223) >>> 0;
      data[y * (width * 3 + 1) + 1 + x] = 100 + (random >>> 24) % 156;
    }
  }
  const header = Buffer.alloc(13);
  header.writeUInt32BE(width, 0);
  header.writeUInt32BE(height, 4);
  header[8] = 8;
  header[9] = 2;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    pngChunk('IHDR', header), pngChunk('IDAT', deflateSync(data)), pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

const source = await PDFDocument.create();
for (let index = 0; index < 3; index += 1) {
  source.addPage([400 + index * 10, 500 + index * 10]).drawText(`Paperplane browser test page ${index + 1}`, { x: 35, y: 100 });
}
const sourcePath = path.join(fixtureDir, 'sample.pdf');
await fs.writeFile(sourcePath, await source.save());
const appendix = await PDFDocument.create();
appendix.addPage([700, 400]).drawText('Appendix', { x: 35, y: 100 });
const appendixPath = path.join(fixtureDir, 'appendix.pdf');
await fs.writeFile(appendixPath, await appendix.save());
const png = landscapePng();
const imagePath = path.join(fixtureDir, 'landscape.png');
await fs.writeFile(imagePath, png);
const scan = await PDFDocument.create();
const embedded = await scan.embedPng(png);
for (let index = 0; index < 3; index += 1) {
  scan.addPage([425, 300]).drawImage(embedded, { x: 0, y: 0, width: 425, height: 300 });
}
const scanBytes = await scan.save();
const scanPath = path.join(fixtureDir, 'scan.pdf');
await fs.writeFile(scanPath, scanBytes);
const invalidPath = path.join(fixtureDir, 'invalid.pdf');
await fs.writeFile(invalidPath, 'This is not a PDF document.');

const browser = await chromium.launch({
  executablePath: process.env.PAPERPLANE_CHROMIUM_PATH || '/usr/bin/chromium',
  args: ['--no-sandbox'],
  headless: true,
});
const context = await browser.newContext({ viewport: { width: 1440, height: 1080 }, acceptDownloads: true });
const page = await context.newPage();
const pageErrors = [];
const consoleErrors = [];
const requests = [];
const workerResponses = [];
const workerUrls = [];
page.on('worker', worker => workerUrls.push(worker.url()));
const results = [];
page.on('pageerror', error => pageErrors.push(error.message));
page.on('console', message => { if (message.type() === 'error') consoleErrors.push(message.text()); });
page.on('request', request => requests.push({ url: request.url(), method: request.method() }));
page.on('response', response => { if (/pdf\.worker/.test(response.url())) workerResponses.push({ url: response.url(), status: response.status() }); });
page.setDefaultTimeout(12000);

async function check(name, operation) {
  try {
    await operation();
    results.push({ name, passed: true });
    console.log(`PASS ${name}`);
  } catch (error) {
    const screenshot = path.join(outputDir, `failure-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`);
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    results.push({ name, passed: false, error: String(error), screenshot });
    console.error(`FAIL ${name}: ${error.message}`);
    await page.getByRole('button', { name: 'Close dialog', exact: true }).click().catch(() => {});
  }
}

async function openTool(name) {
  await page.getByRole('button', { name: `Open ${name}`, exact: true }).click();
  const dialog = page.getByRole('dialog', { name, exact: true });
  await dialog.waitFor();
  return dialog;
}

async function processTool(name, files, configure) {
  const dialog = await openTool(name);
  await dialog.locator('input[type="file"]').setInputFiles(files);
  if (configure) await configure(dialog);
  await dialog.getByRole('button', { name, exact: true }).click();
  await dialog.locator('.result-view, [role="alert"]').waitFor({ timeout: 60000 });
  const error = dialog.getByRole('alert');
  if (await error.count()) throw new Error(await error.textContent() || 'Unexpected processing error');
  await dialog.getByRole('heading', { name: 'Your file is ready.' }).waitFor();
  const downloadPromise = page.waitForEvent('download');
  await dialog.getByRole('link', { name: /^Download (PDF|ZIP)$/ }).click();
  const download = await downloadPromise;
  const target = path.join(downloadDir, download.suggestedFilename());
  await download.saveAs(target);
  const data = await fs.readFile(target);
  assert.ok(data.length > 0, 'Downloaded file must not be empty');
  await dialog.getByRole('button', { name: 'Close dialog', exact: true }).click();
  return { data, target };
}

try {
  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  await check('All tools, search, and categories', async () => {
    assert.equal(await page.locator('.tool-card').count(), 12);
    const search = page.getByRole('textbox', { name: 'Search PDF tools' });
    await search.fill('watermark');
    assert.equal(await page.locator('.tool-card').count(), 1);
    await page.getByRole('button', { name: 'Open Watermark PDF', exact: true }).waitFor();
    await search.fill('no-such-tool-xyz');
    await page.getByRole('heading', { name: 'No tools found just yet.' }).waitFor();
    await page.getByRole('button', { name: 'Clear search', exact: true }).click();
    for (const [category, count] of [['Organize', 5], ['Convert', 2], ['Edit', 4], ['Optimize', 1]]) {
      await page.getByRole('group', { name: 'Filter tools by category' }).getByRole('button', { name: category, exact: true }).click();
      assert.equal(await page.locator('.tool-card').count(), count);
    }
    await page.getByRole('group', { name: 'Filter tools by category' }).getByRole('button', { name: /^All tools/ }).click();
    await page.screenshot({ path: path.join(outputDir, 'desktop-home.png'), fullPage: true });
  });

  await check('Favorites persist across reload', async () => {
    await page.getByRole('button', { name: 'Add Merge PDF to favorites', exact: true }).click();
    await page.reload({ waitUntil: 'networkidle' });
    await page.getByRole('navigation', { name: 'Workspace' }).getByRole('button', { name: /^Favorites/ }).click();
    assert.equal(await page.locator('.tool-card').count(), 1);
    await page.getByRole('button', { name: 'Open Merge PDF', exact: true }).waitFor();
    await page.getByRole('navigation', { name: 'Workspace' }).getByRole('button', { name: /^All tools/ }).click();
  });

  await check('Merge PDF upload, reorder, and download', async () => {
    const { data } = await processTool('Merge PDF', [sourcePath, appendixPath], async dialog => {
      await dialog.getByRole('button', { name: 'Move appendix.pdf up', exact: true }).click();
    });
    const document = await PDFDocument.load(data);
    assert.deepEqual(document.getPages().map(item => item.getWidth()), [700, 400, 410, 420]);
  });

  await check('Split PDF downloads readable individual pages', async () => {
    const { data } = await processTool('Split PDF', sourcePath);
    const zip = await JSZip.loadAsync(data);
    const entries = Object.values(zip.files).filter(entry => !entry.dir);
    assert.equal(entries.length, 3);
    for (const entry of entries) assert.equal((await PDFDocument.load(await entry.async('uint8array'))).getPageCount(), 1);
  });

  await check('Compress PDF renders and reduces scanned PDF size', async () => {
    const { data } = await processTool('Compress PDF', scanPath);
    assert.equal((await PDFDocument.load(data)).getPageCount(), 3);
    assert.ok(data.length < scanBytes.length, `Expected compression: ${data.length} < ${scanBytes.length}`);
  });

  await check('PDF to JPG downloads valid images from browser renderer', async () => {
    const { data } = await processTool('PDF to JPG', sourcePath);
    const zip = await JSZip.loadAsync(data);
    const entries = Object.values(zip.files).filter(entry => !entry.dir);
    assert.equal(entries.length, 3);
    for (const entry of entries) {
      assert.match(entry.name, /\.jpg$/);
      const image = await entry.async('uint8array');
      assert.deepEqual([...image.subarray(0, 3)], [0xff, 0xd8, 0xff]);
      assert.ok(image.byteLength > 1000);
    }
  });

  await check('JPG to PDF honors the displayed portrait orientation', async () => {
    const { data } = await processTool('JPG to PDF', [imagePath]);
    const document = await PDFDocument.load(data);
    assert.equal(document.getPageCount(), 1);
    assert.ok(document.getPage(0).getHeight() > document.getPage(0).getWidth(), 'Portrait selection should produce a portrait page for a landscape image');
  });

  await check('Rotate PDF honors page selection and angle', async () => {
    const { data } = await processTool('Rotate PDF', sourcePath, async dialog => {
      await dialog.getByRole('textbox', { name: /^Pages to rotate/ }).fill('2');
      await dialog.getByRole('combobox', { name: 'Rotation', exact: true }).selectOption('180');
    });
    assert.deepEqual((await PDFDocument.load(data)).getPages().map(item => item.getRotation().angle), [0, 180, 0]);
  });

  await check('Delete pages removes the selected page', async () => {
    const { data } = await processTool('Delete pages', sourcePath, async dialog => {
      await dialog.getByRole('textbox', { name: /^Pages to remove/ }).fill('2');
    });
    assert.deepEqual((await PDFDocument.load(data)).getPages().map(item => item.getWidth()), [400, 420]);
  });

  await check('Organize PDF changes the page sequence', async () => {
    const { data } = await processTool('Organize PDF', sourcePath, async dialog => {
      await dialog.getByRole('textbox', { name: /^Your new page order/ }).fill('3,1,2');
    });
    assert.deepEqual((await PDFDocument.load(data)).getPages().map(item => item.getWidth()), [420, 400, 410]);
  });

  await check('Extract pages keeps the requested pages', async () => {
    const { data } = await processTool('Extract pages', sourcePath, async dialog => {
      await dialog.getByRole('textbox', { name: /^Pages to extract/ }).fill('3,1');
    });
    assert.deepEqual((await PDFDocument.load(data)).getPages().map(item => item.getWidth()), [420, 400]);
  });

  await check('Watermark PDF produces a readable document', async () => {
    const { data } = await processTool('Watermark PDF', sourcePath, async dialog => {
      await dialog.getByRole('textbox', { name: /^Watermark text/ }).fill('REVIEW COPY');
    });
    assert.equal((await PDFDocument.load(data)).getPageCount(), 3);
  });

  await check('Page numbers produces a readable document', async () => {
    const { data } = await processTool('Page numbers', sourcePath);
    assert.equal((await PDFDocument.load(data)).getPageCount(), 3);
  });

  await check('Resize PDF honors US Letter selection', async () => {
    const { data } = await processTool('Resize PDF', sourcePath, async dialog => {
      await dialog.getByRole('combobox', { name: 'Page size', exact: true }).selectOption('letter');
    });
    assert.deepEqual((await PDFDocument.load(data)).getPages().map(item => [item.getWidth(), item.getHeight()]), [[612, 792], [612, 792], [612, 792]]);
  });

  await check('Invalid files show useful recoverable errors', async () => {
    const dialog = await openTool('Rotate PDF');
    await dialog.locator('input[type="file"]').setInputFiles(imagePath);
    await dialog.getByRole('alert').waitFor();
    assert.match(await dialog.getByRole('alert').textContent(), /choose PDF files/i);
    await dialog.locator('input[type="file"]').setInputFiles(invalidPath);
    await dialog.getByRole('button', { name: 'Rotate PDF', exact: true }).click();
    await dialog.getByRole('alert').waitFor();
    assert.match(await dialog.getByRole('alert').textContent(), /valid.*PDF/i);
    await dialog.locator('input[type="file"]').setInputFiles(sourcePath);
    assert.equal(await dialog.getByRole('alert').count(), 0);
    await dialog.getByRole('button', { name: 'Close dialog', exact: true }).click();
  });

  await check('Recent activity persists and can be cleared', async () => {
    await page.reload({ waitUntil: 'networkidle' });
    await page.getByRole('navigation', { name: 'Workspace' }).getByRole('button', { name: /^Recent activity/ }).click();
    assert.equal(await page.locator('.activity-row').count(), 12);
    await page.getByRole('button', { name: 'Clear history', exact: true }).click();
    await page.getByRole('heading', { name: 'A fresh start.' }).waitFor();
    await page.reload({ waitUntil: 'networkidle' });
    const history = await page.evaluate(() => JSON.parse(localStorage.getItem('paperplane-activity')));
    assert.deepEqual(history, []);
  });

  await check('Mobile layout and modal fit a 390px viewport', async () => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'Mobile page should not overflow horizontally');
    await page.screenshot({ path: path.join(outputDir, 'mobile-home.png'), fullPage: true });
    await page.getByRole('button', { name: 'Open navigation', exact: true }).click();
    await page.getByRole('navigation', { name: 'Workspace' }).getByRole('button', { name: /^Favorites/ }).click();
    assert.equal(await page.locator('.tool-card').count(), 1);
    const dialog = await openTool('Merge PDF');
    const bounds = await dialog.boundingBox();
    assert.ok(bounds && bounds.x >= 0 && bounds.x + bounds.width <= 391, 'Dialog should fit viewport');
    await page.screenshot({ path: path.join(outputDir, 'mobile-tool.png'), fullPage: true });
    await page.keyboard.press('Escape');
    assert.equal(await page.getByRole('dialog').count(), 0);
    assert.equal(await page.getByRole('button', { name: 'Open Merge PDF', exact: true }).evaluate(element => element === document.activeElement), true);
  });

  await check('Runtime has no uncaught errors or document uploads', async () => {
    assert.deepEqual(pageErrors, []);
    if (baseUrl.startsWith('file:') || process.env.PAPERPLANE_TEST_STANDALONE === '1') {
      assert.ok(workerUrls.some(url => url.startsWith('blob:')), 'Offline PDF worker should start from a blob');
      assert.equal(requests.filter(request => /^https?:/.test(request.url) && request.url !== baseUrl).length, 0, 'Offline site must not make Internet requests');
      assert.deepEqual(consoleErrors, []);
    } else {
      assert.ok(requests.some(request => /pdf\.worker/.test(request.url)), 'PDF.js browser worker should be requested');
    }
    assert.equal(requests.filter(request => request.method !== 'GET' && request.method !== 'HEAD').length, 0);
  });
} finally {
  await fs.writeFile(path.join(outputDir, 'browser-results.json'), JSON.stringify({ target: baseUrl, testedAt: new Date().toISOString(), results, pageErrors, consoleErrors, workerResponses, workerUrls }, null, 2));
  await browser.close();
}

const failures = results.filter(result => !result.passed);
console.log(`\n${results.length - failures.length}/${results.length} browser checks passed.`);
if (failures.length) process.exitCode = 1;
