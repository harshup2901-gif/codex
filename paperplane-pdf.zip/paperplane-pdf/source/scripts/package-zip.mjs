import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.resolve(process.argv[2] || path.join(root, '..', 'paperplane-pdf.zip'));
const archive = new JSZip();
const folder = archive.folder('paperplane-pdf');
const standalone = await fs.readFile(path.join(root, 'offline', 'index.html'));
await fs.access(path.join(root, 'dist', 'index.html'));

folder.file('index.html', standalone);
folder.file('START-HERE.txt', `PAPERPLANE PDF — READY TO OPEN

1. Right-click this ZIP and choose "Extract All".
2. Open the extracted paperplane-pdf folder.
3. Double-click index.html to open Paperplane in Chrome or Edge.

No installation, terminal, Node.js, or local server is needed.
All twelve PDF tools work locally. Your documents are not uploaded.

The source/ folder is for developers. Its index.html is development
source, so use the index.html at the TOP LEVEL to open the website.

The top-level index.html is the production build and can also be
hosted as-is on a static website host.

Compression may flatten text, links and forms. If it would increase
the file size, Paperplane keeps the original instead.
`);
folder.file('README.md', `# Paperplane PDF

**Extract the ZIP, then double-click the index.html in this folder.**

This is the ready-to-use, self-contained website. It does not need Node.js,
npm, a local server, or an Internet connection. Use a current Chrome or Edge.

## Included

- **index.html** — Open this file to use all 12 PDF tools.
- **START-HERE.txt** — Simple opening instructions.
- **source/** — Complete React, TypeScript, and Vite project with tests.

The tools merge, split, compress, convert PDFs to JPG, convert JPG/PNG to PDF,
rotate, delete, reorder, extract, watermark, number, and resize pages.

Documents stay on your device. Favorites and recent file-name metadata
are saved in this browser; you can clear recent activity in the app.

For development, open a terminal in source/, run npm ci, then npm run dev.
See source/README.md for build, test, and packaging instructions.
`);

async function addDirectory(directory, target) {
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) await addDirectory(full, target.folder(entry.name));
    else if (entry.isFile()) target.file(entry.name, await fs.readFile(full));
  }
}

const source = folder.folder('source');
for (const name of ['src', 'public', 'scripts']) {
  await addDirectory(path.join(root, name), source.folder(name));
}
for (const name of ['.gitignore', 'README.md', 'index.html', 'package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'vite.offline.config.ts']) {
  source.file(name, await fs.readFile(path.join(root, name)));
}


const bytes = await archive.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 9 } });
const checked = await JSZip.loadAsync(bytes, { checkCRC32: true });
if (!(await checked.file('paperplane-pdf/index.html').async('nodebuffer')).equals(standalone)) {
  throw new Error('The packaged website does not match the standalone build.');
}
await fs.mkdir(path.dirname(output), { recursive: true });
await fs.writeFile(output, bytes);
console.log(`Ready-to-open website ZIP: ${output} (${bytes.length.toLocaleString()} bytes)`);
