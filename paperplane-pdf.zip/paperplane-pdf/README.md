# Paperplane PDF

A responsive, browser-based PDF workspace with twelve document tools and a clean, friendly interface. Built with React, TypeScript, Vite, pdf-lib, PDF.js, and JSZip.

## Run locally

Use a current Node.js LTS release (Node.js 22 or newer recommended).

```sh
npm ci
npm run dev
```

Open the local URL shown by Vite. To create and preview a production build:

```sh
npm run build
npm run preview
```

Run the PDF processing tests:

```sh
npm test
```

The tests generate real PDF fixtures, process the resulting files, and check page order, selections, rotations, dimensions, drawing content, ZIP output, invalid inputs, and preservation of the original file. PDF rendering and compression require a browser canvas.

With the dev server running, run the browser checks:

```sh
npm run test:browser
```

The browser runner uses Chromium at `/usr/bin/chromium`. Set `PAPERPLANE_CHROMIUM_PATH` for a different Chromium executable, or `PAPERPLANE_TEST_URL` for a different running app address. It tests every tool through the actual upload and download interface, including compression and rendering. Results and screenshots are written to the ignored `test-results/` directory.

## Twelve tools

| Tool          | What it does                                                               |
| ------------- | -------------------------------------------------------------------------- |
| Merge PDF     | Combines multiple PDFs in the selected file order.                         |
| Split PDF     | Downloads individual pages together in a ZIP archive.                      |
| Compress PDF  | Renders pages at a reduced image quality and packages them into a new PDF. |
| PDF to JPG    | Downloads rendered PDF pages as JPG images in a ZIP archive.               |
| Image to PDF  | Combines JPG and PNG images into a PDF.                                    |
| Rotate PDF    | Turns all pages or a selected page range.                                  |
| Delete pages  | Removes selected pages while retaining the rest.                           |
| Organize PDF  | Rearranges pages into a custom order.                                      |
| Extract pages | Creates a PDF from selected pages in the requested order.                  |
| Watermark PDF | Adds a text watermark to the document.                                     |
| Page numbers  | Adds page numbers throughout a document.                                   |
| Resize PDF    | Fits pages to A4 or US Letter paper.                                       |

Page selections use numbers and ranges, such as `1,3-5`. Page numbers begin at 1. Organize requires every page exactly once; extract accepts a subset in a custom order.

## Privacy and practical limits

Document processing happens locally in your browser. The app does not upload your selected files to a server and does not require an account or API key. Files remain in the current browser session unless you download an output. Fonts, the PDF worker, and application assets are bundled and served by the app; document bytes remain local. Favorites and recent activity metadata (including file names) are stored in local storage, and the history can be cleared from Recent activity.

Compression flattens each page into an image: text becomes nonselectable, and links, forms, annotations, and other interactive document features are not retained. Lower quality can reduce image detail. If the compressed result would be larger, the app returns the original PDF and explains that no reduction was possible. Keep an original copy when these features matter.

PDF to JPG also creates flat images. This app does not provide OCR, Word conversion, password removal, or electronic signatures. Very large files can take time or exceed the browser's available memory. Password-protected or malformed PDFs may be rejected. Watermark text uses the standard PDF font character set.

## Development

The existing checkout is the development workspace; an additional Git worktree is not needed. No backend service, database, external document API, or environment secrets are required. Install dependencies with `npm ci` to use the checked-in lockfile, then run `npm run build` and `npm test` to validate changes.
