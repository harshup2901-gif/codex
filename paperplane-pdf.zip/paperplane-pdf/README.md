# Paperplane PDF

**Extract the ZIP, then double-click the index.html in this folder.**

This is the ready-to-use, self-contained website. It does not need Node.js,
npm, a local server, or an Internet connection. Use a current Chrome or Edge.

## Included

- **index.html** — Open this file to use all 12 PDF tools.
- **START-HERE.txt** — Simple opening instructions.
- **source/** — Complete React, TypeScript, and Vite project with tests.

The tools merge, split, compress, convert PDFs to JPG, convert JPG/PNG to PDF,
rotate, delete, reorder, extract, watermark, number, and resize pages.

Documents stay on your device. Favorites and recent file-name metadata
are saved in this browser; you can clear recent activity in the app.

For development, open a terminal in source/, run npm ci, then npm run dev.
See source/README.md for build, test, and packaging instructions.
