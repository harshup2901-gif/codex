import assert from "node:assert/strict";
import { test } from "node:test";
import { inflateSync } from "node:zlib";
import JSZip from "jszip";
import { PDFArray, PDFDocument, PDFName, PDFRawStream, degrees } from "pdf-lib";
import { parsePageSelection, processPdf } from "./pdf-tools";

async function fixture(name = "sample.pdf", count = 3) {
  const document = await PDFDocument.create();
  for (let index = 0; index < count; index += 1) {
    const page = document.addPage([320 + index * 10, 420 + index * 10]);
    page.drawText(`Original page ${index + 1}`, { x: 30, y: 60 });
  }
  return new File([await document.save()], name, { type: "application/pdf" });
}

async function readPdf(blob: Blob) {
  return PDFDocument.load(await blob.arrayBuffer());
}

function pageTextStreams(document: PDFDocument, pageIndex: number) {
  const contents = document.getPage(pageIndex).node.get(PDFName.of("Contents"));
  const resolved = document.context.lookup(contents);
  const references =
    resolved instanceof PDFArray ? resolved.asArray() : [contents];
  return references
    .map((reference) => {
      const stream = document.context.lookup(reference);
      assert.ok(
        stream instanceof PDFRawStream,
        "Expected a page content stream",
      );
      const filter = stream.dict.get(PDFName.of("Filter"));
      const bytes = stream.getContents();
      return Buffer.from(
        filter?.toString() === "/FlateDecode" ? inflateSync(bytes) : bytes,
      ).toString("latin1");
    })
    .join("\n");
}

test("page selection preserves a requested order and expands ranges to zero-based indexes", () => {
  assert.deepEqual(parsePageSelection("3, 1-2, 5", 5), [2, 0, 1, 4]);
  assert.deepEqual(parsePageSelection(" 1 - 3 ", 3), [0, 1, 2]);
});

test("page selection rejects blank, invalid, overlapping, and out-of-range entries", () => {
  for (const selection of [
    "",
    "0",
    "4",
    "-1",
    "1.5",
    "3-1",
    "one",
    "1,,2",
    "1,1",
    "1-2,2",
  ]) {
    assert.throws(
      () => parsePageSelection(selection, 3),
      Error,
      `Should reject ${JSON.stringify(selection)}`,
    );
  }
});

test("merge combines complete PDFs in their supplied order", async () => {
  const first = await fixture("first.pdf", 2);
  const second = await fixture("second.pdf", 3);
  const result = await processPdf("merge", [first, second], {});
  const merged = await readPdf(result.blob);
  assert.deepEqual(
    merged.getPages().map((page) => page.getWidth()),
    [320, 330, 320, 330, 340],
  );
  assert.match(result.filename, /\.pdf$/i);
  assert.equal(result.blob.type, "application/pdf");
});

test("split returns a readable ZIP of individual one-page PDFs", async () => {
  const result = await processPdf("split", [await fixture()], {});
  const zip = await JSZip.loadAsync(await result.blob.arrayBuffer());
  const entries = Object.values(zip.files).filter((entry) => !entry.dir);
  assert.equal(entries.length, 3);
  const widths: number[] = [];
  for (const entry of entries) {
    assert.match(entry.name, /\.pdf$/i);
    const document = await PDFDocument.load(await entry.async("uint8array"));
    assert.equal(document.getPageCount(), 1);
    widths.push(document.getPage(0).getWidth());
  }
  assert.deepEqual(
    widths.sort((a, b) => a - b),
    [320, 330, 340],
  );
  assert.match(result.filename, /\.zip$/i);
});

test("split can limit its archive to selected pages", async () => {
  const result = await processPdf("split", [await fixture()], { pages: "3,1" });
  const zip = await JSZip.loadAsync(await result.blob.arrayBuffer());
  assert.equal(
    Object.values(zip.files).filter((entry) => !entry.dir).length,
    2,
  );
});

test("extract uses the requested page order", async () => {
  const result = await processPdf("extract", [await fixture()], {
    pages: "3,1",
  });
  const document = await readPdf(result.blob);
  assert.deepEqual(
    document.getPages().map((page) => page.getWidth()),
    [340, 320],
  );
});

test("delete pages retains the unselected pages in their original order", async () => {
  const result = await processPdf("delete-pages", [await fixture()], {
    pages: "2",
  });
  const document = await readPdf(result.blob);
  assert.deepEqual(
    document.getPages().map((page) => page.getWidth()),
    [320, 340],
  );
});

test("delete pages refuses an empty selection or deletion of the entire document", async () => {
  const file = await fixture();
  await assert.rejects(
    processPdf("delete-pages", [file], { pages: "" }),
    Error,
  );
  await assert.rejects(
    processPdf("delete-pages", [file], { pages: "1-3" }),
    Error,
  );
});

test("organize rearranges each page exactly as requested", async () => {
  const result = await processPdf("organize", [await fixture()], {
    pages: "3,1,2",
  });
  const document = await readPdf(result.blob);
  assert.deepEqual(
    document.getPages().map((page) => page.getWidth()),
    [340, 320, 330],
  );
});

test("organize refuses a sequence that omits or repeats a page", async () => {
  const file = await fixture();
  await assert.rejects(processPdf("organize", [file], { pages: "3,1" }), Error);
  await assert.rejects(
    processPdf("organize", [file], { pages: "3,1,1" }),
    Error,
  );
});

test("rotation affects only selected pages", async () => {
  const result = await processPdf("rotate", [await fixture()], {
    pages: "1,3",
    rotation: 90,
  });
  const document = await readPdf(result.blob);
  assert.deepEqual(
    document.getPages().map((page) => page.getRotation().angle),
    [90, 0, 90],
  );
});

test("rotation rejects angles that are not multiples of 90 degrees", async () => {
  await assert.rejects(
    processPdf("rotate", [await fixture()], { rotation: 45 }),
    Error,
  );
});

test("watermark adds the supplied text while preserving existing page content", async () => {
  const result = await processPdf("watermark", [await fixture()], {
    watermark: "DRAFT",
  });
  const document = await readPdf(result.blob);
  assert.equal(document.getPageCount(), 3);
  for (let index = 0; index < 3; index += 1) {
    const stream = pageTextStreams(document, index);
    assert.match(
      stream,
      /4452414654/i,
      "Watermark text should be encoded in the page",
    );
    assert.match(
      stream,
      /4f726967696e616c2070616765/i,
      "Original text should remain in the page",
    );
  }
});

test("watermark rejects an explicitly blank label", async () => {
  await assert.rejects(
    processPdf("watermark", [await fixture()], { watermark: "  " }),
    Error,
  );
});

test("page numbers add visible text on every page without removing original content", async () => {
  const file = await fixture();
  const original = await readPdf(file);
  const result = await processPdf("page-numbers", [file], {});
  const document = await readPdf(result.blob);
  assert.equal(document.getPageCount(), 3);
  for (let index = 0; index < 3; index += 1) {
    const before = pageTextStreams(original, index);
    const after = pageTextStreams(document, index);
    assert.ok(
      after.length > before.length,
      "Numbered page should contain an added drawing operation",
    );
    assert.match(after, /4f726967696e616c2070616765/i);
    const textOperations = after.match(/\bTj\b/g) ?? [];
    assert.ok(
      textOperations.length >= 2,
      "Page should contain original text and an added page number",
    );
    assert.ok(
      after
        .toLowerCase()
        .includes(Buffer.from(`${index + 1} / 3`).toString("hex")),
      "The number should match the page position and total",
    );
  }
});

test("resize outputs letter pages and retains document content", async () => {
  const result = await processPdf("resize", [await fixture()], {
    pageSize: "letter",
  });
  const document = await readPdf(result.blob);
  assert.equal(document.getPageCount(), 3);
  for (const [index, page] of document.getPages().entries()) {
    assert.equal(page.getWidth(), 612);
    assert.equal(page.getHeight(), 792);
    assert.match(
      pageTextStreams(document, index),
      /\bDo\b/,
      "Resized page should draw the original content",
    );
  }
});

test("resize outputs A4 pages", async () => {
  const result = await processPdf("resize", [await fixture()], {
    pageSize: "a4",
  });
  const document = await readPdf(result.blob);
  assert.ok(Math.abs(document.getPage(0).getWidth() - 595.28) < 0.1);
  assert.ok(Math.abs(document.getPage(0).getHeight() - 841.89) < 0.1);
});

test("resize accepts truly blank pages and preserves their visible orientation", async () => {
  const source = await PDFDocument.create();
  source.addPage([400, 600]);
  source.addPage([600, 400]);
  source.addPage([400, 600]).setRotation(degrees(90));
  const file = new File([await source.save()], "blank-pages.pdf", {
    type: "application/pdf",
  });
  const result = await processPdf("resize", [file], { pageSize: "letter" });
  const document = await readPdf(result.blob);
  assert.deepEqual(
    document.getPages().map((page) => [page.getWidth(), page.getHeight()]),
    [
      [612, 792],
      [792, 612],
      [792, 612],
    ],
  );
});

test("page numbers remain inside the displayed crop and upright at every page rotation", async () => {
  const source = await PDFDocument.create();
  const rotations = [0, 90, 180, 270];
  for (const rotation of rotations) {
    const page = source.addPage([700, 700]);
    page.setCropBox(80, 110, 400, 260);
    page.setRotation(degrees(rotation));
    page.drawText("Original", { x: 100, y: 150 });
  }
  const file = new File([await source.save()], "cropped-rotated.pdf", {
    type: "application/pdf",
  });
  const result = await processPdf("page-numbers", [file], {});
  const document = await readPdf(result.blob);
  for (const [index, rotation] of rotations.entries()) {
    const page = document.getPage(index);
    assert.deepEqual(page.getCropBox(), {
      x: 80,
      y: 110,
      width: 400,
      height: 260,
    });
    assert.equal(page.getRotation().angle, rotation);
    const matrices = [
      ...pageTextStreams(document, index).matchAll(/((?:[-\d.e]+\s+){6})Tm/g),
    ];
    const matrix = matrices.at(-1)?.[1].trim().split(/\s+/).map(Number);
    assert.ok(matrix, "Page number should include a text placement matrix");
    const [a, b, , , x, y] = matrix;
    assert.ok(
      x >= 80 && x <= 480 && y >= 110 && y <= 370,
      "Text origin should lie inside the crop",
    );
    assert.ok(Math.abs(a - Math.cos((rotation * Math.PI) / 180)) < 0.0001);
    assert.ok(Math.abs(b - Math.sin((rotation * Math.PI) / 180)) < 0.0001);
    const distanceFromVisualBottom =
      rotation === 0
        ? y - 110
        : rotation === 90
          ? 480 - x
          : rotation === 180
            ? 370 - y
            : x - 80;
    assert.ok(
      Math.abs(distanceFromVisualBottom - 23) < 0.0001,
      "Page number should retain its bottom margin",
    );
  }
});

test("watermark stays within a cropped, rotated page and keeps its visible angle", async () => {
  const source = await PDFDocument.create();
  const page = source.addPage([700, 700]);
  page.setCropBox(80, 110, 400, 260);
  page.setRotation(degrees(90));
  const file = new File([await source.save()], "cropped-watermark.pdf", {
    type: "application/pdf",
  });
  const result = await processPdf("watermark", [file], { watermark: "DRAFT" });
  const document = await readPdf(result.blob);
  const stream = pageTextStreams(document, 0);
  assert.match(stream, /4452414654/i);
  const matrices = [...stream.matchAll(/((?:[-\d.e]+\s+){6})Tm/g)];
  const matrix = matrices.at(-1)?.[1].trim().split(/\s+/).map(Number);
  assert.ok(matrix);
  const [a, b, , , x, y] = matrix;
  assert.ok(x >= 80 && x <= 480 && y >= 110 && y <= 370);
  assert.ok(Math.abs(a - Math.cos((120 * Math.PI) / 180)) < 0.0001);
  assert.ok(Math.abs(b - Math.sin((120 * Math.PI) / 180)) < 0.0001);
});

test("image-to-pdf embeds each PNG as a page", async () => {
  const png = Buffer.from(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aDQ0AAAAASUVORK5CYII=",
    "base64",
  );
  const files = ["one.png", "two.png"].map(
    (name) => new File([png], name, { type: "image/png" }),
  );
  const result = await processPdf("image-to-pdf", files, {
    pageSize: "letter",
  });
  const document = await readPdf(result.blob);
  assert.equal(document.getPageCount(), 2);
  for (let index = 0; index < 2; index += 1) {
    assert.match(
      pageTextStreams(document, index),
      /\bDo\b/,
      "Each page should draw an embedded image",
    );
  }
});

test("PDF tools reject missing files, invalid PDF data, and insufficient merge inputs", async () => {
  await assert.rejects(processPdf("rotate", [], {}), Error);
  await assert.rejects(processPdf("merge", [await fixture()], {}), Error);
  await assert.rejects(
    processPdf("extract", [new File(["not a pdf"], "invalid.pdf")], {}),
    Error,
  );
});

test("operations reject out-of-range page selections and preserve the input file", async () => {
  const file = await fixture();
  const before = Buffer.from(await file.arrayBuffer());
  await assert.rejects(processPdf("extract", [file], { pages: "9" }), Error);
  await processPdf("rotate", [file], { rotation: 180 });
  assert.deepEqual(Buffer.from(await file.arrayBuffer()), before);
});
