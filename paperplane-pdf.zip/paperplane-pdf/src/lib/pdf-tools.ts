import { PDFDocument, StandardFonts, degrees, rgb } from "pdf-lib";
import type { PDFPage } from "pdf-lib";
import JSZip from "jszip";

export type ToolId =
  | "merge"
  | "split"
  | "compress"
  | "pdf-to-jpg"
  | "image-to-pdf"
  | "rotate"
  | "delete-pages"
  | "organize"
  | "extract"
  | "watermark"
  | "page-numbers"
  | "resize";

export interface ToolOptions {
  pages?: string;
  rotation?: number;
  watermark?: string;
  /** JPEG quality, between 0.1 and 1. */
  quality?: number;
  pageSize?: "a4" | "letter";
  imageOrientation?: "portrait" | "landscape";
}

export interface ProcessResult {
  blob: Blob;
  filename: string;
  note?: string;
}

const PAGE_SIZES = {
  a4: [595.28, 841.89],
  letter: [612, 792],
} as const;

/** Parse a one-based page list into unique, ordered, zero-based indexes. */
export function parsePageSelection(value: string, total: number): number[] {
  if (!Number.isInteger(total) || total < 1) {
    throw new Error("This PDF does not contain any pages.");
  }
  if (!value.trim()) {
    throw new Error("Enter at least one page number or range, such as 1, 3-5.");
  }
  const pages: number[] = [];
  const seen = new Set<number>();
  for (const part of value.split(",")) {
    const match = part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
    if (!match) {
      throw new Error(
        "Use page numbers and ranges separated by commas, such as 1, 3-5.",
      );
    }
    const first = Number(match[1]);
    const last = Number(match[2] ?? match[1]);
    if (first < 1 || last > total || first > total || last < 1) {
      throw new Error(`Page numbers must be between 1 and ${total}.`);
    }
    if (last < first) {
      throw new Error("Page ranges must go from lower to higher, such as 3-5.");
    }
    for (let page = first; page <= last; page += 1) {
      if (seen.has(page)) {
        throw new Error(
          `Page ${page} appears more than once. Include each page only once.`,
        );
      }
      seen.add(page);
      pages.push(page - 1);
    }
  }
  return pages;
}

function pdfBlob(bytes: Uint8Array): Blob {
  // An owned ArrayBuffer also satisfies stricter BlobPart types in newer TS versions.
  const buffer = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(buffer).set(bytes);
  return new Blob([buffer], { type: "application/pdf" });
}

function baseName(name: string): string {
  return (
    name
      .replace(/\.[^.]+$/, "")
      .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "-")
      .trim() || "document"
  );
}

function selection(options: ToolOptions, total: number): number[] {
  return options.pages?.trim()
    ? parsePageSelection(options.pages, total)
    : Array.from({ length: total }, (_, index) => index);
}

function jpegQuality(value: number | undefined, fallback: number): number {
  const quality = value ?? fallback;
  if (!Number.isFinite(quality) || quality < 0.1 || quality > 1) {
    throw new Error("Image quality must be between 0.1 and 1.");
  }
  return quality;
}

function targetSize(options: ToolOptions): readonly [number, number] {
  const size = options.pageSize ?? "a4";
  if (!(size in PAGE_SIZES)) throw new Error("Choose A4 or Letter paper size.");
  return PAGE_SIZES[size];
}

/** Work in the page's displayed coordinates, including crop boxes and rotation. */
function pageGeometry(page: PDFPage) {
  const crop = page.getCropBox();
  const rotation = ((page.getRotation().angle % 360) + 360) % 360;
  const sideways = rotation === 90 || rotation === 270;
  return {
    width: sideways ? crop.height : crop.width,
    height: sideways ? crop.width : crop.height,
    rotation,
    point(x: number, y: number): { x: number; y: number } {
      switch (rotation) {
        case 90:
          return { x: crop.x + crop.width - y, y: crop.y + x };
        case 180:
          return { x: crop.x + crop.width - x, y: crop.y + crop.height - y };
        case 270:
          return { x: crop.x + y, y: crop.y + crop.height - x };
        default:
          return { x: crop.x + x, y: crop.y + y };
      }
    },
  };
}

async function loadPdf(file: File): Promise<PDFDocument> {
  if (file.size === 0)
    throw new Error(
      `“${file.name}” is empty. Choose a PDF that contains pages.`,
    );
  try {
    const document = await PDFDocument.load(await file.arrayBuffer(), {
      updateMetadata: false,
    });
    if (document.getPageCount() === 0)
      throw new Error("This PDF does not contain any pages.");
    return document;
  } catch (error) {
    if (
      error instanceof Error &&
      /encrypt|password/i.test(`${error.name} ${error.message}`)
    ) {
      throw new Error(
        `“${file.name}” is password protected. Save an unlocked copy and try again.`,
      );
    }
    if (
      error instanceof Error &&
      error.message === "This PDF does not contain any pages."
    )
      throw error;
    throw new Error(
      `We could not read “${file.name}”. Make sure it is a valid, undamaged PDF.`,
    );
  }
}

async function savePdf(
  document: PDFDocument,
  filename: string,
  note?: string,
): Promise<ProcessResult> {
  return {
    blob: pdfBlob(await document.save({ useObjectStreams: true })),
    filename,
    ...(note ? { note } : {}),
  };
}

function toJpeg(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) =>
        blob
          ? resolve(blob)
          : reject(
              new Error(
                "The page image could not be created. Try a smaller PDF.",
              ),
            ),
      "image/jpeg",
      quality,
    );
  });
}

/** Import the browser renderer only for operations that actually rasterize pages. */
async function rasterizePdf(
  file: File,
  options: ToolOptions,
  format: "compress" | "pdf-to-jpg",
  progress: (message: string) => void,
): Promise<ProcessResult> {
  if (typeof document === "undefined") {
    throw new Error("This tool needs a browser with canvas support.");
  }
  const quality = jpegQuality(
    options.quality,
    format === "compress" ? 0.55 : 0.92,
  );
  const [pdfjs, worker] = await Promise.all([
    import("pdfjs-dist"),
    import("pdfjs-dist/build/pdf.worker.min.mjs?url"),
  ]);
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  const loadingTask = pdfjs.getDocument({
    data: new Uint8Array(await file.arrayBuffer()),
    useSystemFonts: true,
    isEvalSupported: false,
  });
  try {
    const source = await loadingTask.promise;
    if (source.numPages === 0)
      throw new Error("This PDF does not contain any pages.");
    const indexes =
      format === "pdf-to-jpg"
        ? selection(options, source.numPages)
        : Array.from({ length: source.numPages }, (_, index) => index);
    const zip = new JSZip();
    const output = await PDFDocument.create();
    for (let index = 0; index < indexes.length; index += 1) {
      progress(`Rendering page ${index + 1} of ${indexes.length}…`);
      const sourcePage = await source.getPage(indexes[index] + 1);
      const original = sourcePage.getViewport({ scale: 1 });
      // Cap canvas size to avoid exceeding browser memory or canvas limits on poster-size pages.
      const desiredScale = format === "compress" ? 1.25 : 2;
      const scale = Math.min(
        desiredScale,
        4096 / Math.max(original.width, original.height),
      );
      const viewport = sourcePage.getViewport({ scale });
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.ceil(viewport.width));
      canvas.height = Math.max(1, Math.ceil(viewport.height));
      const context = canvas.getContext("2d", { alpha: false });
      if (!context)
        throw new Error(
          "Your browser could not create a canvas. Try reopening this page.",
        );
      try {
        await sourcePage.render({
          canvasContext: context,
          viewport,
          background: "rgb(255,255,255)",
        }).promise;
        const jpeg = await toJpeg(canvas, quality);
        const bytes = await jpeg.arrayBuffer();
        if (format === "pdf-to-jpg") {
          zip.file(
            `${baseName(file.name)}-page-${String(indexes[index] + 1).padStart(3, "0")}.jpg`,
            bytes,
          );
        } else {
          const embedded = await output.embedJpg(bytes);
          const page = output.addPage([original.width, original.height]);
          page.drawImage(embedded, {
            x: 0,
            y: 0,
            width: original.width,
            height: original.height,
          });
        }
      } finally {
        canvas.width = 0;
        canvas.height = 0;
        sourcePage.cleanup();
      }
    }
    progress("Preparing your download…");
    if (format === "pdf-to-jpg") {
      return {
        blob: await zip.generateAsync({ type: "blob" }),
        filename: `${baseName(file.name)}-images.zip`,
      };
    }
    const compressed = pdfBlob(await output.save({ useObjectStreams: true }));
    if (compressed.size >= file.size) {
      return {
        blob: new Blob([await file.arrayBuffer()], { type: "application/pdf" }),
        filename: `${baseName(file.name)}-optimized.pdf`,
        note: "Your original PDF is already smaller than this compression result, so we kept the original quality and file size.",
      };
    }
    const reduction = Math.round((1 - compressed.size / file.size) * 100);
    return {
      blob: compressed,
      filename: `${baseName(file.name)}-compressed.pdf`,
      note: `${reduction}% smaller. Pages are flattened to images; text selection, links, and form fields are not preserved.`,
    };
  } catch (error) {
    if (
      error instanceof Error &&
      /password|encrypt/i.test(`${error.name} ${error.message}`)
    ) {
      throw new Error(
        `“${file.name}” is password protected. Save an unlocked copy and try again.`,
      );
    }
    if (error instanceof Error && /InvalidPDF|MissingPDF/.test(error.name)) {
      throw new Error(
        `We could not read “${file.name}”. Make sure it is a valid, undamaged PDF.`,
      );
    }
    throw error;
  } finally {
    await loadingTask.destroy();
  }
}

export async function processPdf(
  tool: ToolId,
  files: File[],
  options: ToolOptions = {},
  onProgress?: (message: string) => void,
): Promise<ProcessResult> {
  const progress = onProgress ?? (() => {});
  if (files.length === 0) throw new Error("Choose a file to get started.");
  if (tool === "merge" && files.length < 2)
    throw new Error("Choose at least two PDFs to merge.");
  if (tool !== "merge" && tool !== "image-to-pdf" && files.length !== 1) {
    throw new Error("Choose one PDF for this tool.");
  }
  progress("Reading your files…");
  if (tool === "compress" || tool === "pdf-to-jpg") {
    return rasterizePdf(files[0], options, tool, progress);
  }
  if (tool === "merge") {
    const merged = await PDFDocument.create();
    for (let index = 0; index < files.length; index += 1) {
      progress(`Adding PDF ${index + 1} of ${files.length}…`);
      const source = await loadPdf(files[index]);
      const pages = await merged.copyPages(source, source.getPageIndices());
      pages.forEach((page) => merged.addPage(page));
    }
    return savePdf(merged, "merged-document.pdf");
  }
  if (tool === "image-to-pdf") {
    const output = await PDFDocument.create();
    const [paperWidth, paperHeight] = targetSize(options);
    for (let index = 0; index < files.length; index += 1) {
      progress(`Adding image ${index + 1} of ${files.length}…`);
      const file = files[index];
      const bytes = new Uint8Array(await file.arrayBuffer());
      const isPng =
        bytes[0] === 0x89 &&
        bytes[1] === 0x50 &&
        bytes[2] === 0x4e &&
        bytes[3] === 0x47;
      const isJpg = bytes[0] === 0xff && bytes[1] === 0xd8;
      if (!isPng && !isJpg)
        throw new Error(
          `“${file.name}” is not a supported image. Choose a JPG or PNG file.`,
        );
      let image;
      try {
        image = isPng
          ? await output.embedPng(bytes)
          : await output.embedJpg(bytes);
      } catch {
        throw new Error(
          `We could not read “${file.name}”. Make sure it is an undamaged JPG or PNG image.`,
        );
      }
      const landscape = options.imageOrientation
        ? options.imageOrientation === "landscape"
        : image.width > image.height;
      const width = landscape ? paperHeight : paperWidth;
      const height = landscape ? paperWidth : paperHeight;
      const scale = Math.min(
        (width - 48) / image.width,
        (height - 48) / image.height,
      );
      const page = output.addPage([width, height]);
      page.drawImage(image, {
        x: (width - image.width * scale) / 2,
        y: (height - image.height * scale) / 2,
        width: image.width * scale,
        height: image.height * scale,
      });
    }
    return savePdf(output, "images-to-pdf.pdf");
  }

  const file = files[0];
  const source = await loadPdf(file);
  const total = source.getPageCount();
  const name = baseName(file.name);

  switch (tool) {
    case "split": {
      const indexes = selection(options, total);
      const zip = new JSZip();
      for (let index = 0; index < indexes.length; index += 1) {
        progress(`Splitting page ${index + 1} of ${indexes.length}…`);
        const output = await PDFDocument.create();
        const [page] = await output.copyPages(source, [indexes[index]]);
        output.addPage(page);
        zip.file(
          `${name}-page-${String(indexes[index] + 1).padStart(3, "0")}.pdf`,
          await output.save(),
        );
      }
      return {
        blob: await zip.generateAsync({ type: "blob" }),
        filename: `${name}-split.zip`,
      };
    }
    case "extract":
    case "organize": {
      const indexes = selection(options, total);
      if (tool === "organize" && indexes.length !== total) {
        throw new Error(
          `Include every page exactly once to reorder this PDF (${total} pages). Use Extract PDF to keep only selected pages.`,
        );
      }
      const output = await PDFDocument.create();
      const pages = await output.copyPages(source, indexes);
      pages.forEach((page) => output.addPage(page));
      return savePdf(
        output,
        `${name}-${tool === "extract" ? "extracted" : "reordered"}.pdf`,
      );
    }
    case "delete-pages": {
      const indexes = parsePageSelection(options.pages ?? "", total);
      if (indexes.length === total)
        throw new Error("Keep at least one page in your PDF.");
      [...indexes]
        .sort((a, b) => b - a)
        .forEach((index) => source.removePage(index));
      return savePdf(source, `${name}-edited.pdf`);
    }
    case "rotate": {
      const rotation = options.rotation ?? 90;
      if (!Number.isFinite(rotation) || rotation % 90 !== 0) {
        throw new Error("Choose a rotation in multiples of 90 degrees.");
      }
      for (const index of selection(options, total)) {
        const page = source.getPage(index);
        const angle =
          (((page.getRotation().angle + rotation) % 360) + 360) % 360;
        page.setRotation(degrees(angle));
      }
      return savePdf(source, `${name}-rotated.pdf`);
    }
    case "watermark": {
      const text = (options.watermark ?? "CONFIDENTIAL").trim();
      if (!text) throw new Error("Enter some text for your watermark.");
      if (text.length > 120)
        throw new Error(
          "Keep your watermark under 120 characters so it fits on the page.",
        );
      const font = await source.embedFont(StandardFonts.HelveticaBold);
      try {
        font.encodeText(text);
      } catch {
        throw new Error(
          "Use Latin letters, numbers, and standard punctuation for the watermark.",
        );
      }
      for (const index of selection(options, total)) {
        const page = source.getPage(index);
        const geometry = pageGeometry(page);
        const { width, height } = geometry;
        const size = Math.min(
          64,
          (width * 0.76) / font.widthOfTextAtSize(text, 1),
        );
        const textWidth = font.widthOfTextAtSize(text, size);
        const angle = Math.PI / 6;
        page.drawText(text, {
          ...geometry.point(
            width / 2 -
              (textWidth * Math.cos(angle) - size * Math.sin(angle)) / 2,
            height / 2 -
              (textWidth * Math.sin(angle) + size * Math.cos(angle)) / 2,
          ),
          size,
          font,
          color: rgb(0.36, 0.38, 0.45),
          opacity: 0.22,
          rotate: degrees(geometry.rotation + 30),
        });
      }
      return savePdf(source, `${name}-watermarked.pdf`);
    }
    case "page-numbers": {
      const font = await source.embedFont(StandardFonts.Helvetica);
      for (const index of selection(options, total)) {
        const page = source.getPage(index);
        const geometry = pageGeometry(page);
        const { width } = geometry;
        const text = `${index + 1} / ${total}`;
        const size = 10;
        const textWidth = font.widthOfTextAtSize(text, size);
        page.drawRectangle({
          ...geometry.point((width - textWidth) / 2 - 5, 18),
          width: textWidth + 10,
          height: 18,
          rotate: degrees(geometry.rotation),
          color: rgb(1, 1, 1),
          opacity: 0.9,
        });
        page.drawText(text, {
          ...geometry.point((width - textWidth) / 2, 23),
          size,
          font,
          rotate: degrees(geometry.rotation),
          color: rgb(0.25, 0.25, 0.3),
        });
      }
      return savePdf(source, `${name}-numbered.pdf`);
    }
    case "resize": {
      const output = await PDFDocument.create();
      const [paperWidth, paperHeight] = targetSize(options);
      for (let index = 0; index < total; index += 1) {
        progress(`Resizing page ${index + 1} of ${total}…`);
        const original = source.getPage(index);
        const crop = original.getCropBox();
        const {
          width: visibleWidth,
          height: visibleHeight,
          rotation,
        } = pageGeometry(original);
        const landscape = visibleWidth > visibleHeight;
        const width = landscape ? paperHeight : paperWidth;
        const height = landscape ? paperWidth : paperHeight;
        const page = output.addPage([width, height]);
        // Blank pages do not have a content stream for pdf-lib to embed.
        if (!original.node.Contents()) continue;
        const embedded = await output.embedPage(original, {
          left: crop.x,
          bottom: crop.y,
          right: crop.x + crop.width,
          top: crop.y + crop.height,
        });
        const scale = Math.min(width / visibleWidth, height / visibleHeight);
        const displayWidth = visibleWidth * scale;
        const displayHeight = visibleHeight * scale;
        const left = (width - displayWidth) / 2;
        const bottom = (height - displayHeight) / 2;
        page.drawPage(embedded, {
          x: left + (rotation === 180 || rotation === 270 ? displayWidth : 0),
          y: bottom + (rotation === 90 || rotation === 180 ? displayHeight : 0),
          width: embedded.width * scale,
          height: embedded.height * scale,
          rotate: degrees(-rotation),
        });
      }
      return savePdf(output, `${name}-${options.pageSize ?? "a4"}.pdf`);
    }
    default:
      throw new Error("Choose a PDF tool to continue.");
  }
}
