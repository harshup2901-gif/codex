import { useCallback, useEffect, useRef, useState } from "react";
import type { DragEvent, ReactNode } from "react";
import {
  ArrowDown,
  ArrowDownToLine,
  ArrowRight,
  ArrowUp,
  Check,
  CheckCheck,
  ChevronRight,
  Clock3,
  CloudOff,
  Download,
  FileImage,
  FileOutput,
  FilePlus2,
  FileStack,
  FileText,
  FolderOpen,
  Grid2X2,
  Heart,
  HelpCircle,
  Image,
  LayoutGrid,
  LoaderCircle,
  Maximize2,
  Menu,
  Merge,
  RotateCw,
  Scissors,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Trash2,
  Type,
  Upload,
  WandSparkles,
  X,
  Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { ProcessResult, ToolId, ToolOptions } from "./lib/pdf-tools";

type Category = "All tools" | "Organize" | "Convert" | "Edit" | "Optimize";
type Tool = {
  id: ToolId;
  name: string;
  description: string;
  category: Category;
  icon: LucideIcon;
  color: string;
  popular?: boolean;
  accept: string;
};
const tools: Tool[] = [
  {
    id: "merge",
    name: "Merge PDF",
    description: "Good things come together. Combine PDFs into one.",
    category: "Organize",
    icon: Merge,
    color: "green",
    popular: true,
    accept: ".pdf",
  },
  {
    id: "split",
    name: "Split PDF",
    description: "Break a big document into perfectly sized pieces.",
    category: "Organize",
    icon: Scissors,
    color: "orange",
    accept: ".pdf",
  },
  {
    id: "compress",
    name: "Compress PDF",
    description: "Less size. More space. Lighten up your scanned PDFs.",
    category: "Optimize",
    icon: ArrowDownToLine,
    color: "purple",
    popular: true,
    accept: ".pdf",
  },
  {
    id: "pdf-to-jpg",
    name: "PDF to JPG",
    description: "Turn every page into a picture worth sharing.",
    category: "Convert",
    icon: FileImage,
    color: "blue",
    accept: ".pdf",
  },
  {
    id: "image-to-pdf",
    name: "JPG to PDF",
    description: "Give your JPGs and PNGs a new home in a PDF.",
    category: "Convert",
    icon: Image,
    color: "pink",
    accept: ".jpg,.jpeg,.png",
  },
  {
    id: "rotate",
    name: "Rotate PDF",
    description: "A fresh perspective, one page at a time.",
    category: "Edit",
    icon: RotateCw,
    color: "orange",
    accept: ".pdf",
  },
  {
    id: "delete-pages",
    name: "Delete pages",
    description: "Keep the good stuff. Remove the pages you don’t need.",
    category: "Organize",
    icon: Trash2,
    color: "pink",
    accept: ".pdf",
  },
  {
    id: "organize",
    name: "Organize PDF",
    description: "Put every page right where it belongs.",
    category: "Organize",
    icon: LayoutGrid,
    color: "purple",
    accept: ".pdf",
  },
  {
    id: "extract",
    name: "Extract pages",
    description: "Pick your favorite pages and make them their own PDF.",
    category: "Organize",
    icon: FileOutput,
    color: "blue",
    accept: ".pdf",
  },
  {
    id: "watermark",
    name: "Watermark PDF",
    description: "Make your mark. Add a little text to every page.",
    category: "Edit",
    icon: Type,
    color: "green",
    accept: ".pdf",
  },
  {
    id: "page-numbers",
    name: "Page numbers",
    description: "Help everyone stay on the same page.",
    category: "Edit",
    icon: FilePlus2,
    color: "orange",
    accept: ".pdf",
  },
  {
    id: "resize",
    name: "Resize PDF",
    description: "Find the perfect fit with A4 or Letter page sizes.",
    category: "Edit",
    icon: Maximize2,
    color: "purple",
    accept: ".pdf",
  },
];
const categories: Category[] = [
  "All tools",
  "Organize",
  "Convert",
  "Edit",
  "Optimize",
];
type Activity = { name: string; tool: ToolId; date: number; size: number };
function readLocal<T>(key: string, fallback: T): T {
  try {
    return JSON.parse(localStorage.getItem(key) || "null") ?? fallback;
  } catch {
    return fallback;
  }
}
function bytes(size: number) {
  return size < 1024 * 1024
    ? `${Math.max(1, Math.round(size / 1024))} KB`
    : `${(size / 1024 / 1024).toFixed(1)} MB`;
}
function Logo({ small = false }: { small?: boolean }) {
  return (
    <div className={`brand ${small ? "small" : ""}`}>
      <span className="brand-mark">
        <svg viewBox="0 0 32 32" aria-hidden="true">
          <path d="M4 14 28 5 21 28 15 19 4 14Z" fill="currentColor" />
          <path
            d="m15 19 9-10-12 7"
            fill="none"
            stroke="#214e40"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span>
        paperplane<span className="brand-dot">.</span>
      </span>
    </div>
  );
}
function HeroArtwork() {
  return (
    <svg
      className="hero-art"
      viewBox="0 0 480 330"
      role="img"
      aria-label="An illustration of colorful PDF documents coming together"
    >
      <defs>
        <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
          <feDropShadow
            dx="0"
            dy="15"
            stdDeviation="16"
            floodColor="#456b55"
            floodOpacity=".12"
          />
        </filter>
        <linearGradient id="paper" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#fff" />
          <stop offset="1" stopColor="#f9fcf8" />
        </linearGradient>
        <linearGradient id="mint" x1="0" y1="0" x2="0" y2="1">
          <stop stopColor="#e1eee3" />
          <stop offset="1" stopColor="#d0e2d1" />
        </linearGradient>
      </defs>
      <ellipse
        cx="253"
        cy="188"
        rx="151"
        ry="139"
        fill="#dce9d7"
        opacity=".55"
      />
      <circle
        cx="267"
        cy="187"
        r="115"
        fill="none"
        stroke="#c7d8c3"
        strokeDasharray="3 7"
      />
      <path
        d="M60 230C-4 166 79 108 116 135s-30 86-56 44S55 77 146 52"
        fill="none"
        stroke="#8ba995"
        strokeWidth="1.5"
        strokeDasharray="5 6"
      />
      <g transform="translate(150 69) rotate(-15 81 106)" filter="url(#shadow)">
        <rect width="153" height="207" rx="12" fill="url(#mint)" />
        <rect x="22" y="26" width="47" height="8" rx="4" fill="#9ab99d" />
        <rect x="22" y="49" width="108" height="5" rx="2.5" fill="#aec7ae" />
        <rect x="22" y="64" width="84" height="5" rx="2.5" fill="#aec7ae" />
        <rect x="22" y="103" width="109" height="77" rx="5" fill="#bbd2ba" />
        <path d="m29 163 26-28 20 16 23-35 28 47" fill="#89b08e" />
      </g>
      <g transform="translate(239 73) rotate(16 75 98)" filter="url(#shadow)">
        <rect width="142" height="188" rx="12" fill="#f5e4c7" />
        <rect x="21" y="27" width="53" height="8" rx="4" fill="#c3a976" />
        <rect x="21" y="52" width="99" height="5" rx="2.5" fill="#ddcaa5" />
        <rect x="21" y="68" width="80" height="5" rx="2.5" fill="#ddcaa5" />
        <circle cx="70" cy="123" r="27" fill="#e6cb9b" />
        <path d="M70 96v27h27A27 27 0 0 0 70 96" fill="#cfa66b" />
      </g>
      <g transform="translate(197 87) rotate(-3 77 100)" filter="url(#shadow)">
        <path
          d="M12 0h106l37 37v163a12 12 0 0 1-12 12H12a12 12 0 0 1-12-12V12A12 12 0 0 1 12 0"
          fill="url(#paper)"
        />
        <path d="M118 0v25a12 12 0 0 0 12 12h25" fill="#e5eee1" />
        <rect x="23" y="35" width="52" height="24" rx="6" fill="#f9dfd7" />
        <text
          x="49"
          y="51"
          textAnchor="middle"
          fontFamily="Arial,sans-serif"
          fontSize="12"
          fontWeight="700"
          letterSpacing="1"
          fill="#be705d"
        >
          PDF
        </text>
        <rect x="23" y="80" width="105" height="6" rx="3" fill="#cbd7c9" />
        <rect x="23" y="96" width="88" height="6" rx="3" fill="#dce4d9" />
        <rect x="23" y="112" width="98" height="6" rx="3" fill="#dce4d9" />
        <rect x="23" y="142" width="109" height="40" rx="6" fill="#ecf1e6" />
        <path
          d="m40 165 10 7 16-20m15 8h31m-31 9h20"
          fill="none"
          stroke="#78957b"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
      <g transform="translate(326 248)">
        <circle r="28" fill="#347057" />
        <path
          d="m-11 0 8 8 16-17"
          fill="none"
          stroke="white"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
      <g transform="translate(373 54) rotate(14)">
        <path d="m0 16 55-16-16 48-12-21Z" fill="#568266" />
        <path
          d="M27 27 48 5 19 22"
          fill="none"
          stroke="#dce9d7"
          strokeWidth="1.5"
        />
      </g>
      <path
        d="m117 68 3 8 8 3-8 3-3 8-3-8-8-3 8-3Zm287 136 3 8 8 3-8 3-3 8-3-8-8-3 8-3Z"
        fill="#88a47b"
      />
      <circle cx="149" cy="283" r="5" fill="#c4a76c" />
      <circle cx="418" cy="139" r="4" fill="#c4a76c" />
      <path d="m99 269 5 5m-5 0 5-5" stroke="#8da680" strokeWidth="2" />
    </svg>
  );
}

function Dialog({
  children,
  onClose,
  label,
  wide = false,
}: {
  children: ReactNode;
  onClose: () => void;
  label: string;
  wide?: boolean;
}) {
  const panel = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const old = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panel.current?.focus();
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        const items = panel.current?.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input, select, textarea, a[href], [tabindex="0"]',
        );
        if (!items?.length) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (
          event.shiftKey &&
          (document.activeElement === first ||
            document.activeElement === panel.current)
        ) {
          event.preventDefault();
          last.focus();
        } else if (
          !event.shiftKey &&
          (document.activeElement === last ||
            document.activeElement === panel.current)
        ) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", handler);
    return () => {
      document.body.style.overflow = old;
      document.removeEventListener("keydown", handler);
      previous?.focus();
    };
  }, [onClose]);
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        ref={panel}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={label}
        className={`modal ${wide ? "wide" : ""}`}
      >
        <button
          aria-label="Close dialog"
          className="icon-button modal-close"
          onClick={onClose}
        >
          <X size={20} />
        </button>
        {children}
      </div>
    </div>
  );
}

function ToolModal({
  tool,
  onClose,
  onComplete,
}: {
  tool: Tool;
  onClose: () => void;
  onComplete: (result: ProcessResult, tool: ToolId) => void;
}) {
  const [files, setFiles] = useState<File[]>([]);
  const [dragging, setDragging] = useState(false);
  const [options, setOptions] = useState<ToolOptions>({
    rotation: 90,
    quality: 0.65,
    watermark: "DRAFT",
    pageSize: "a4",
    imageOrientation: "portrait",
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("Getting your files ready…");
  const [result, setResult] = useState<ProcessResult | null>(null);
  const [downloadUrl, setDownloadUrl] = useState("");
  const [pageCount, setPageCount] = useState<number | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const multi = tool.id === "merge" || tool.id === "image-to-pdf";
  const Icon = tool.icon;
  useEffect(() => {
    if (!result) return;
    const url = URL.createObjectURL(result.blob);
    setDownloadUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [result]);
  useEffect(() => {
    let active = true;
    setPageCount(null);
    if (files.length === 1 && tool.id !== "image-to-pdf") {
      import("pdf-lib")
        .then(async ({ PDFDocument }) => {
          const pdf = await PDFDocument.load(await files[0].arrayBuffer());
          if (active) setPageCount(pdf.getPageCount());
        })
        .catch(() => {});
    }
    return () => {
      active = false;
    };
  }, [files, tool.id]);
  const addFiles = (newFiles: FileList | File[]) => {
    setError("");
    const incoming = Array.from(newFiles);
    const valid = incoming.every((f) =>
      tool.id === "image-to-pdf"
        ? /\.(jpe?g|png)$/i.test(f.name)
        : /\.pdf$/i.test(f.name),
    );
    if (!valid) {
      setError(
        `Please choose ${tool.id === "image-to-pdf" ? "JPG or PNG images" : "PDF files"} for this tool.`,
      );
      return;
    }
    if (!multi && incoming.length > 1) {
      setError(
        "This tool works with one PDF at a time. Please select a single file.",
      );
      return;
    }
    const next = multi ? [...files, ...incoming] : incoming;
    if (next.reduce((n, f) => n + f.size, 0) > 150 * 1024 * 1024) {
      setError(
        "Please keep the combined file size under 150 MB to help your browser run smoothly.",
      );
      return;
    }
    setFiles(next);
  };
  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (!busy) addFiles(e.dataTransfer.files);
  };
  const move = (index: number, offset: number) => {
    const next = [...files];
    [next[index], next[index + offset]] = [next[index + offset], next[index]];
    setFiles(next);
  };
  const run = async () => {
    setError("");
    if (
      ["extract", "delete-pages", "organize"].includes(tool.id) &&
      !options.pages?.trim()
    ) {
      setError(
        tool.id === "organize"
          ? "Enter your new page order, including every page exactly once."
          : "Enter the page numbers or ranges you want to use.",
      );
      return;
    }
    setBusy(true);
    try {
      const { processPdf } = await import("./lib/pdf-tools");
      const output = await processPdf(tool.id, files, options, setProgress);
      setResult(output);
      onComplete(output, tool.id);
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "We couldn’t process this file. Please try a different PDF.",
      );
    } finally {
      setBusy(false);
    }
  };
  const option = (value: Partial<ToolOptions>) =>
    setOptions((o) => ({ ...o, ...value }));
  return (
    <Dialog onClose={onClose} label={tool.name} wide>
      <div className="tool-modal-heading">
        <span className={`tool-icon ${tool.color}`}>
          <Icon size={25} />
        </span>
        <div>
          <div className="eyebrow">A LITTLE LESS PAPERWORK</div>
          <h2>{tool.name}</h2>
        </div>
      </div>
      <p className="modal-description">{tool.description}</p>
      {result ? (
        <div className="result-view">
          <div className="success-mark">
            <CheckCheck size={35} />
          </div>
          <h3>Your file is ready.</h3>
          <p>A little PDF magic. A little more time for you.</p>
          <div className="result-file">
            <FileText size={25} />
            <div>
              <strong>{result.filename}</strong>
              <span>{bytes(result.blob.size)} · Ready to download</span>
            </div>
            <span className="ready-dot" />
          </div>
          {result.note && <p className="result-note">{result.note}</p>}
          <a
            className="primary-button download-button"
            href={downloadUrl}
            download={result.filename}
          >
            <Download size={18} /> Download{" "}
            {result.filename.endsWith(".zip") ? "ZIP" : "PDF"}
          </a>
          <button
            className="text-button"
            onClick={() => {
              setResult(null);
              setFiles([]);
              setError("");
            }}
          >
            Work on another file <ArrowRight size={15} />
          </button>
        </div>
      ) : (
        <>
          <input
            className="visually-hidden"
            ref={input}
            type="file"
            accept={tool.accept}
            multiple={multi}
            disabled={busy}
            onChange={(e) => {
              if (e.target.files) addFiles(e.target.files);
              e.target.value = "";
            }}
            aria-label={`Choose files for ${tool.name}`}
          />
          <button
            className={`dropzone ${dragging ? "dragging" : ""} ${files.length ? "compact" : ""}`}
            disabled={busy}
            onClick={() => input.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
          >
            <span className="upload-circle">
              <Upload size={25} />
            </span>
            <strong>
              {files.length
                ? multi
                  ? "Add more files"
                  : "Choose a different file"
                : `Drop your ${tool.id === "image-to-pdf" ? "images" : multi ? "PDFs" : "PDF"} here`}
            </strong>
            <span>
              or <b>browse files</b> on your device
            </span>
            <small>
              {tool.id === "image-to-pdf" ? "JPG and PNG" : "PDF files"} · Up to
              150 MB total
            </small>
          </button>
          {files.length > 0 && (
            <div className="selected-files">
              {files.map((file, index) => (
                <div className="selected-file" key={`${file.name}-${index}`}>
                  <span className="file-number">{index + 1}</span>
                  <FileText size={20} />
                  <div className="file-info">
                    <strong>{file.name}</strong>
                    <span>
                      {bytes(file.size)}
                      {pageCount !== null
                        ? ` · ${pageCount} ${pageCount === 1 ? "page" : "pages"}`
                        : ""}
                    </span>
                  </div>
                  {multi && (
                    <div className="reorder-controls">
                      <button
                        className="icon-button"
                        aria-label={`Move ${file.name} up`}
                        disabled={index === 0 || busy}
                        onClick={() => move(index, -1)}
                      >
                        <ArrowUp size={15} />
                      </button>
                      <button
                        className="icon-button"
                        aria-label={`Move ${file.name} down`}
                        disabled={index === files.length - 1 || busy}
                        onClick={() => move(index, 1)}
                      >
                        <ArrowDown size={15} />
                      </button>
                    </div>
                  )}
                  <button
                    className="icon-button"
                    aria-label={`Remove ${file.name}`}
                    disabled={busy}
                    onClick={() =>
                      setFiles(files.filter((_, i) => i !== index))
                    }
                  >
                    <X size={17} />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="tool-options">
            {["extract", "delete-pages", "organize", "rotate"].includes(
              tool.id,
            ) && (
              <label>
                {tool.id === "organize"
                  ? "Your new page order"
                  : tool.id === "delete-pages"
                    ? "Pages to remove"
                    : tool.id === "extract"
                      ? "Pages to extract"
                      : "Pages to rotate (optional)"}
                <input
                  disabled={busy}
                  value={options.pages || ""}
                  onChange={(e) => option({ pages: e.target.value })}
                  placeholder={
                    tool.id === "organize"
                      ? "e.g. 3, 1, 2"
                      : tool.id === "rotate"
                        ? "Leave empty to rotate all pages"
                        : "e.g. 1, 3-5"
                  }
                />
                <small>
                  {tool.id === "organize"
                    ? "Include every page exactly once, in the order you want."
                    : "Use page numbers starting at 1. Separate pages with commas or use a range."}
                </small>
              </label>
            )}
            {tool.id === "rotate" && (
              <label>
                Rotation
                <select
                  disabled={busy}
                  value={options.rotation}
                  onChange={(e) => option({ rotation: Number(e.target.value) })}
                >
                  <option value={90}>90° clockwise</option>
                  <option value={180}>180° upside down</option>
                  <option value={270}>90° counterclockwise</option>
                </select>
              </label>
            )}
            {tool.id === "watermark" && (
              <label>
                Watermark text
                <input
                  maxLength={80}
                  disabled={busy}
                  value={options.watermark}
                  onChange={(e) => option({ watermark: e.target.value })}
                  placeholder="e.g. DRAFT or CONFIDENTIAL"
                />
                <small>
                  A subtle diagonal watermark will appear on every page. Latin
                  characters supported.
                </small>
              </label>
            )}
            {["resize", "image-to-pdf"].includes(tool.id) && (
              <label>
                Page size
                <select
                  disabled={busy}
                  value={options.pageSize}
                  onChange={(e) =>
                    option({ pageSize: e.target.value as "a4" | "letter" })
                  }
                >
                  <option value="a4">A4 — 210 × 297 mm</option>
                  <option value="letter">US Letter — 8.5 × 11 in</option>
                </select>
              </label>
            )}
            {tool.id === "image-to-pdf" && (
              <label>
                Orientation
                <select
                  disabled={busy}
                  value={options.imageOrientation || "portrait"}
                  onChange={(e) =>
                    option({
                      imageOrientation: e.target.value as
                        | "portrait"
                        | "landscape",
                    })
                  }
                >
                  <option value="portrait">Portrait</option>
                  <option value="landscape">Landscape</option>
                </select>
              </label>
            )}
            {["compress", "pdf-to-jpg"].includes(tool.id) && (
              <label>
                {tool.id === "compress" ? "Compression level" : "Image quality"}
                <select
                  disabled={busy}
                  value={options.quality}
                  onChange={(e) => option({ quality: Number(e.target.value) })}
                >
                  <option value={0.4}>Smaller files — standard quality</option>
                  <option value={0.65}>Balanced — recommended</option>
                  <option value={0.9}>Higher quality — larger files</option>
                </select>
              </label>
            )}
            {tool.id === "compress" && (
              <div className="option-notice">
                <SlidersHorizontal size={17} />
                <p>
                  Best for scanned PDFs. Pages become images, so text, links,
                  and forms won’t stay editable. File size reduction depends on
                  the original.
                </p>
              </div>
            )}
            {tool.id === "split" && (
              <div className="option-notice">
                <FileStack size={18} />
                <p>
                  Every page becomes a separate PDF, neatly packed into a ZIP
                  file.
                </p>
              </div>
            )}
            {tool.id === "page-numbers" && (
              <div className="option-notice">
                <FilePlus2 size={18} />
                <p>
                  Page numbers will be added at the bottom center of every page,
                  starting at 1.
                </p>
              </div>
            )}
            {tool.id === "pdf-to-jpg" && (
              <div className="option-notice">
                <FileImage size={18} />
                <p>
                  Every page becomes a JPG image. Download them together as a
                  ZIP file.
                </p>
              </div>
            )}
          </div>
          {error && (
            <div className="error-message" role="alert">
              {error}
            </div>
          )}
          <button
            className="primary-button process-button"
            disabled={!files.length || busy}
            aria-busy={busy}
            aria-live="polite"
            onClick={run}
          >
            {busy ? (
              <>
                <LoaderCircle className="spin" size={19} />
                {progress}
              </>
            ) : (
              <>
                {tool.name}
                <ArrowRight size={18} />
              </>
            )}
          </button>
          <div className="modal-privacy">
            <ShieldCheck size={14} /> Your files stay on your device. Always.
          </div>
        </>
      )}
    </Dialog>
  );
}

export default function App() {
  const [category, setCategory] = useState<Category>("All tools");
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"all" | "favorites" | "recent">("all");
  const [favorites, setFavorites] = useState<ToolId[]>(() => {
    const v = readLocal<unknown>("paperplane-favorites", []);
    return Array.isArray(v)
      ? v.filter((id) => tools.some((t) => t.id === id))
      : [];
  });
  const [activity, setActivity] = useState<Activity[]>(() => {
    const v = readLocal<unknown>("paperplane-activity", []);
    return Array.isArray(v)
      ? v
          .filter(
            (a) =>
              a &&
              typeof a.name === "string" &&
              typeof a.date === "number" &&
              typeof a.size === "number" &&
              tools.some((t) => t.id === a.tool),
          )
          .slice(0, 20)
      : [];
  });
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);
  const [info, setInfo] = useState<"how" | "privacy" | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const toolsRef = useRef<HTMLElement>(null);
  useEffect(() => {
    try {
      localStorage.setItem("paperplane-favorites", JSON.stringify(favorites));
    } catch {
      /* Storage is optional. */
    }
  }, [favorites]);
  useEffect(() => {
    try {
      localStorage.setItem("paperplane-activity", JSON.stringify(activity));
    } catch {
      /* Storage is optional. */
    }
  }, [activity]);
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, []);
  const closeTool = useCallback(() => setSelectedTool(null), []);
  const closeInfo = useCallback(() => setInfo(null), []);
  const toggleFavorite = (id: ToolId) =>
    setFavorites((current) =>
      current.includes(id) ? current.filter((i) => i !== id) : [...current, id],
    );
  const navigate = (next: "all" | "favorites" | "recent") => {
    setView(next);
    setCategory("All tools");
    setSearch("");
    setMobileOpen(false);
  };
  const filtered = tools.filter(
    (tool) =>
      (view !== "favorites" || favorites.includes(tool.id)) &&
      (category === "All tools" || tool.category === category) &&
      `${tool.name} ${tool.description} ${tool.category}`
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  const complete = (result: ProcessResult, tool: ToolId) =>
    setActivity((current) =>
      [
        {
          name: result.filename,
          tool,
          date: Date.now(),
          size: result.blob.size,
        },
        ...current,
      ].slice(0, 20),
    );
  const explore = () => {
    navigate("all");
    window.setTimeout(
      () =>
        toolsRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        }),
      20,
    );
  };
  return (
    <div className="app-shell">
      {mobileOpen && (
        <button
          className="sidebar-overlay"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
        />
      )}
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <a
          className="brand-link"
          href="#"
          aria-label="Paperplane home"
          onClick={(e) => {
            e.preventDefault();
            navigate("all");
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <Logo />
        </a>
        <button
          className="mobile-sidebar-close icon-button"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
        >
          <X size={20} />
        </button>
        <div className="sidebar-label">YOUR WORKSPACE</div>
        <nav className="main-nav" aria-label="Workspace">
          <button
            className={view === "all" ? "active" : ""}
            onClick={() => navigate("all")}
          >
            <Grid2X2 size={19} />
            <span>All tools</span>
            <span className="nav-count">12</span>
          </button>
          <button
            className={view === "recent" ? "active" : ""}
            onClick={() => navigate("recent")}
          >
            <Clock3 size={19} />
            <span>Recent activity</span>
            {activity.length > 0 && (
              <span className="subtle-count">{activity.length}</span>
            )}
          </button>
          <button
            className={view === "favorites" ? "active" : ""}
            onClick={() => navigate("favorites")}
          >
            <Star size={19} />
            <span>Favorites</span>
            {favorites.length > 0 && (
              <span className="subtle-count">{favorites.length}</span>
            )}
          </button>
        </nav>
        <div className="sidebar-divider" />
        <div className="sidebar-label">A LITTLE HELP</div>
        <nav className="help-nav" aria-label="Help">
          <button
            onClick={() => {
              setInfo("how");
              setMobileOpen(false);
            }}
          >
            <HelpCircle size={18} />
            How it works
            <ChevronRight size={15} />
          </button>
          <button
            onClick={() => {
              setInfo("privacy");
              setMobileOpen(false);
            }}
          >
            <ShieldCheck size={18} />
            Privacy & security
            <ChevronRight size={15} />
          </button>
        </nav>
        <div className="sidebar-bottom">
          <div className="privacy-card">
            <div className="privacy-card-icon">
              <ShieldCheck size={24} />
              <span className="tiny-spark">✧</span>
            </div>
            <h3>Your files. Your business.</h3>
            <p>
              Everything happens right in your browser. We never see your files.
            </p>
            <button onClick={() => setInfo("privacy")}>
              That’s our promise <ArrowUp size={13} />
            </button>
          </div>
          <div className="sidebar-foot">
            <span className="status-dot" />A lighter way to work.
            <Heart size={12} />
          </div>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="mobile-menu icon-button"
              aria-label="Open navigation"
              onClick={() => setMobileOpen(true)}
            >
              <Menu size={22} />
            </button>
            <span className="breadcrumb-home">Workspace</span>
            <ChevronRight size={14} />
            <strong>
              {view === "all"
                ? "All tools"
                : view === "favorites"
                  ? "Favorites"
                  : "Recent activity"}
            </strong>
          </div>
          <div className="topbar-right">
            <span className="browser-badge">
              <span className="status-dot" />
              All good. All local.
            </span>
            <span className="topbar-divider" />
            <span className="free-badge">
              <Sparkles size={13} />
              Free, for everyone
            </span>
          </div>
        </header>
        <main>
          {view === "all" && (
            <section className="hero">
              <div className="hero-content">
                <div className="eyebrow">
                  <span className="status-dot" />
                  YOUR EVERYDAY PDF TOOLKIT
                </div>
                <h1>
                  Big ideas.
                  <br />
                  <span>Less paperwork.</span>
                  <svg
                    className="heading-underline"
                    viewBox="0 0 262 13"
                    aria-hidden="true"
                  >
                    <path
                      d="M3 9Q120-3 259 5"
                      stroke="#96b485"
                      strokeWidth="3"
                      fill="none"
                      strokeLinecap="round"
                    />
                  </svg>
                </h1>
                <p>
                  All the PDF tools you need, in one happy place.
                  <br className="desktop-break" /> Simple, secure, and ready
                  when you are.
                </p>
                <div className="hero-actions">
                  <button className="primary-button" onClick={explore}>
                    Explore the tools
                    <ArrowRight size={16} />
                  </button>
                  <button
                    className="hero-secondary"
                    onClick={() => setInfo("how")}
                  >
                    <span className="play-icon">▷</span>How it works
                  </button>
                </div>
                <div className="hero-note">
                  <Check size={13} />
                  100% free<span>·</span>No sign-up needed<span>·</span>Just
                  good tools
                </div>
              </div>
              <HeroArtwork />
              <div className="hero-art-label">
                <span className="small-star">✦</span>Less busywork, more
                possibility.
              </div>
            </section>
          )}
          <section
            className="tools-section"
            ref={toolsRef}
            aria-label="PDF tools"
          >
            <div className="section-heading">
              <div>
                <div className="title-line">
                  <h2>
                    {view === "favorites"
                      ? "Your go-to tools."
                      : view === "recent"
                        ? "A little look back."
                        : "A tool for every to-do."}
                  </h2>
                  {view !== "recent" && (
                    <span className="section-count">
                      {view === "favorites" ? favorites.length : 12} tools
                    </span>
                  )}
                </div>
                <p>
                  {view === "favorites"
                    ? "The ones you love, always close at hand."
                    : view === "recent"
                      ? "Your recent projects, remembered on this device."
                      : "Big tasks or small tweaks. You’ve got this."}
                </p>
              </div>
              {view !== "recent" && (
                <label className="search-box">
                  <Search size={17} />
                  <input
                    ref={searchRef}
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Find your tool…"
                    aria-label="Search PDF tools"
                  />
                  {search ? (
                    <button
                      aria-label="Clear search"
                      onClick={() => setSearch("")}
                    >
                      <X size={15} />
                    </button>
                  ) : (
                    <kbd>⌘ K</kbd>
                  )}
                </label>
              )}
            </div>
            {view !== "recent" && (
              <>
                <div className="filter-row">
                  <div
                    className="filter-tabs"
                    role="group"
                    aria-label="Filter tools by category"
                  >
                    {categories.map((c) => (
                      <button
                        key={c}
                        className={category === c ? "selected" : ""}
                        onClick={() => setCategory(c)}
                      >
                        {c === "All tools" && <Grid2X2 size={14} />} {c}
                        {c === "All tools" && (
                          <span>
                            {view === "favorites" ? favorites.length : 12}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                  <span className="filter-caption">
                    <WandSparkles size={14} />A little PDF magic
                  </span>
                </div>
                <div className="tool-grid">
                  {filtered.map((tool) => {
                    const Icon = tool.icon;
                    const isFavorite = favorites.includes(tool.id);
                    return (
                      <article className="tool-card" key={tool.id}>
                        <button
                          className="tool-card-main"
                          onClick={() => setSelectedTool(tool)}
                          aria-label={`Open ${tool.name}`}
                        >
                          <div className="card-top">
                            <span className={`tool-icon ${tool.color}`}>
                              <Icon size={23} strokeWidth={1.7} />
                            </span>
                            {tool.popular && (
                              <span className="popular-badge">POPULAR</span>
                            )}
                          </div>
                          <h3>{tool.name}</h3>
                          <p>{tool.description}</p>
                          <span className="card-go">
                            <ArrowRight size={17} />
                          </span>
                        </button>
                        <button
                          className={`favorite-button ${isFavorite ? "saved" : ""}`}
                          aria-label={`${isFavorite ? "Remove" : "Add"} ${tool.name} ${isFavorite ? "from" : "to"} favorites`}
                          aria-pressed={isFavorite}
                          onClick={() => toggleFavorite(tool.id)}
                        >
                          <Star
                            size={15}
                            fill={isFavorite ? "currentColor" : "none"}
                          />
                        </button>
                      </article>
                    );
                  })}
                </div>
                {!filtered.length && (
                  <div className="empty-state">
                    <span className="empty-icon">
                      {view === "favorites" && favorites.length === 0 ? (
                        <Star size={27} />
                      ) : (
                        <Search size={27} />
                      )}
                    </span>
                    <h3>
                      {view === "favorites" && favorites.length === 0
                        ? "Make yourself at home."
                        : "No tools found just yet."}
                    </h3>
                    <p>
                      {view === "favorites" && favorites.length === 0
                        ? "Tap the star on any tool to keep it here for next time."
                        : "Try a different search or explore all 12 tools."}
                    </p>
                    <button
                      className="secondary-button"
                      onClick={() => {
                        navigate("all");
                      }}
                    >
                      Explore all tools <ArrowRight size={16} />
                    </button>
                  </div>
                )}
              </>
            )}
            {view === "recent" &&
              (activity.length ? (
                <>
                  <div className="activity-heading">
                    <span>
                      {activity.length} recent{" "}
                      {activity.length === 1 ? "project" : "projects"} · File
                      contents are never stored
                    </span>
                    <button
                      className="text-button"
                      onClick={() => setActivity([])}
                    >
                      <Trash2 size={14} />
                      Clear history
                    </button>
                  </div>
                  <div className="activity-list">
                    {activity.map((item, i) => {
                      const tool = tools.find((t) => t.id === item.tool)!;
                      const Icon = tool.icon;
                      return (
                        <div className="activity-row" key={`${item.date}-${i}`}>
                          <span className={`tool-icon ${tool.color}`}>
                            <Icon size={21} />
                          </span>
                          <div className="activity-info">
                            <strong>{item.name}</strong>
                            <span>
                              {tool.name} · {bytes(item.size)} ·{" "}
                              {new Date(item.date).toLocaleDateString(
                                undefined,
                                { month: "short", day: "numeric" },
                              )}
                            </span>
                          </div>
                          <button
                            className="secondary-button"
                            onClick={() => setSelectedTool(tool)}
                          >
                            Use tool again
                            <ArrowRight size={15} />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                  <p className="history-note">
                    History remembers file names and tools on this device. To
                    process a file again, choose it from your device.
                  </p>
                </>
              ) : (
                <div className="empty-state">
                  <span className="empty-icon">
                    <Clock3 size={28} />
                  </span>
                  <h3>A fresh start.</h3>
                  <p>
                    Once you finish your first project, you’ll find its details
                    here.
                  </p>
                  <button className="secondary-button" onClick={explore}>
                    Find your first tool
                    <ArrowRight size={16} />
                  </button>
                </div>
              ))}
          </section>
          {view === "all" && (
            <section className="benefits" aria-label="Why Paperplane">
              <div>
                <span className="benefit-icon">
                  <ShieldCheck size={22} />
                </span>
                <div>
                  <h3>Private by design</h3>
                  <p>Your files never leave your device.</p>
                </div>
              </div>
              <div>
                <span className="benefit-icon">
                  <Zap size={22} />
                </span>
                <div>
                  <h3>Less waiting. More doing.</h3>
                  <p>No uploads. No queues. Just results.</p>
                </div>
              </div>
              <div>
                <span className="benefit-icon">
                  <Heart size={22} />
                </span>
                <div>
                  <h3>Good tools. Zero price tag.</h3>
                  <p>Every feature. For everyone. Always.</p>
                </div>
              </div>
            </section>
          )}
          <footer className="footer">
            <p>Made for the work. And the life around it.</p>
            <span>
              Keep it simple.{" "}
              <span className="footer-script">Keep it moving.</span>
              <svg viewBox="0 0 25 25" aria-hidden="true">
                <path
                  d="m3 11 19-7-6 18-5-8Z"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                />
                <path d="m11 14 8-7" stroke="currentColor" strokeWidth="1.5" />
              </svg>
            </span>
          </footer>
        </main>
      </div>
      {selectedTool && (
        <ToolModal
          key={selectedTool.id}
          tool={selectedTool}
          onClose={closeTool}
          onComplete={complete}
        />
      )}
      {info && (
        <Dialog
          onClose={closeInfo}
          label={
            info === "how" ? "How Paperplane works" : "Privacy and security"
          }
        >
          <div className="info-icon">
            {info === "how" ? (
              <Sparkles size={27} />
            ) : (
              <ShieldCheck size={28} />
            )}
          </div>
          <div className="eyebrow">SIMPLE FEELS GOOD</div>
          <h2>
            {info === "how"
              ? "From to-do to ta-da."
              : "Your files. Your business."}
          </h2>
          <p className="modal-description">
            {info === "how"
              ? "Three little steps. One less thing on your list."
              : "Privacy is built into the way Paperplane works."}
          </p>
          {info === "how" ? (
            <div className="how-steps">
              <div>
                <span>01</span>
                <section>
                  <h3>Find your tool</h3>
                  <p>
                    Pick from 12 tools to combine, convert, or give your PDFs a
                    little polish.
                  </p>
                </section>
              </div>
              <div>
                <span>02</span>
                <section>
                  <h3>Make it yours</h3>
                  <p>
                    Choose your files and adjust the settings. Your browser does
                    all the work.
                  </p>
                </section>
              </div>
              <div>
                <span>03</span>
                <section>
                  <h3>Download. Done.</h3>
                  <p>
                    Save your finished PDF or ZIP to your device and get on with
                    your day.
                  </p>
                </section>
              </div>
            </div>
          ) : (
            <div className="privacy-details">
              <div>
                <CloudOff size={23} />
                <section>
                  <h3>No file uploads</h3>
                  <p>
                    Documents are processed in your browser’s memory. Their
                    contents are never sent to a server.
                  </p>
                </section>
              </div>
              <div>
                <FolderOpen size={23} />
                <section>
                  <h3>You’re in control</h3>
                  <p>
                    Only favorites and recent activity details, including file
                    names, are saved in this browser. Clear history whenever you
                    like.
                  </p>
                </section>
              </div>
              <div>
                <ShieldCheck size={23} />
                <section>
                  <h3>No account needed</h3>
                  <p>
                    Open a tool and get to work. No sign-ups, subscriptions, or
                    hidden limits on how often you use it.
                  </p>
                </section>
              </div>
            </div>
          )}
          <button className="primary-button info-done" onClick={closeInfo}>
            Sounds good
            <Check size={17} />
          </button>
        </Dialog>
      )}
    </div>
  );
}
